package com.example.veda;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    ImageView focus,maditation,stress,Relex,creative,study,sleep,memory;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        focus = findViewById(R.id.focusbtn);
        maditation = findViewById(R.id.maditationBtn);
        stress = findViewById(R.id.stressBtn);
        Relex = findViewById(R.id.relexBtn);
        creative = findViewById(R.id.creativeBtn);
        study = findViewById(R.id.studyBtn);
        sleep = findViewById(R.id.sleepBtn);
        memory = findViewById(R.id.memoryBtn);

        //calling the function

        focus.setOnClickListener(this);
        maditation.setOnClickListener(this);
        stress.setOnClickListener(this);
        Relex.setOnClickListener(this);
        creative .setOnClickListener(this);
        study.setOnClickListener(this);
        sleep.setOnClickListener(this);
        memory.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {

        switch (v.getId()){

            case R.id.focusbtn:

              Intent focus = new Intent(this,MusicActivity.class);
              startActivity(focus);
                break;
           case R.id.maditationBtn:

               Intent maditation = new Intent(this,MusicActivity.class);
               startActivity(maditation);

                break;
            case R.id.stressBtn:

                Intent stress = new Intent(this,MusicActivity.class);
                startActivity(stress);

                break;
            case R.id.relexBtn:

                Intent relex = new Intent(this,MusicActivity.class);
                startActivity(relex);

                break;
            case R.id.creativeBtn:

                Intent creative = new Intent(this,MusicActivity.class);
                startActivity(creative);

                break;
            case R.id.studyBtn:

                Intent study = new Intent(this,MusicActivity.class);
                startActivity(study);

                break;
            case R.id.sleepBtn:

                Intent sleep = new Intent(this,MusicActivity.class);
                startActivity(sleep);

                break;
            case R.id.memoryBtn:

                Intent memory = new Intent(this,MusicActivity.class);
                startActivity(memory);

                break;
        }
    }
}