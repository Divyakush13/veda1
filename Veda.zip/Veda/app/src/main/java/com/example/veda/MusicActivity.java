package com.example.veda;

import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.media.Image;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.Toast;

import com.karumi.dexter.Dexter;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionDeniedResponse;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.single.PermissionListener;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class MusicActivity extends AppCompatActivity {

    ImageView play, nextBtn, previous;
    MediaPlayer mediaPlayer;

    SeekBar seekBar;

    Handler handler=new Handler();
    Runnable runnable;

    private boolean checkPermision = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_music);


        play=findViewById(R.id.playBtn);
        nextBtn=findViewById(R.id.nextBtn);
        previous=findViewById(R.id.previousBtn);




        MediaPlayer mediaPlayer = new MediaPlayer();
       try {
           mediaPlayer.setDataSource("https://firebasestorage.googleapis.com/v0/b/veda-64c05.appspot.com/o/Y2Mate.is%20-%20Call%20Me%20When%20You%20Want-Call%20Me%20When%20You%20Need%20Ringtone%20%20Lil%20Nas%20X%20MONTERO%20%20Ringtone%20(Download%20Link%20%E2%AC%87)--VHS27lUDSQ-128k-1640431421835.mp3?alt=media&token=0ca3887d-5c28-4e49-86a2-209cd15cf9fa");
           mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
               @Override
               public void onPrepared(MediaPlayer mp) {

                   mp.start();

               }
           });
           mediaPlayer.prepare();
                  } catch (IOException e) {
           e.printStackTrace();
       }



    }
    private boolean valadationPermission() {


        Dexter.withContext(this)
                .withPermission(Manifest.permission.READ_EXTERNAL_STORAGE)
                .withListener(new PermissionListener() {
                    @Override
                    public void onPermissionGranted(PermissionGrantedResponse permissionGrantedResponse) {
                        checkPermision=true;
                    }

                    @Override
                    public void onPermissionDenied(PermissionDeniedResponse permissionDeniedResponse) {
                        checkPermision=true;
                    }

                    @Override
                    public void onPermissionRationaleShouldBeShown(PermissionRequest permissionRequest, PermissionToken permissionToken) {
                        permissionToken.continuePermissionRequest();
                    }
                })
                .check();
      return checkPermision;

    }

}